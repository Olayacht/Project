<?php
// CRITICAL: Ensure there is NO space or HTML before the <?php tag above

// 1. Manual Loading - Adjust folder names if they differ on your server
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

// Helper: Spintax Parser
function processSpintax($text) {
    return preg_replace_callback('/\{(((?>[^\{\}]+)|(?R))*)\}/', function($t) {
        $parts = explode('|', $t[1]);
        return $parts[array_rand($parts)];
    }, $text);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mail = new PHPMailer(true);
    
    try {
        // Parse Inputs safely to prevent notices and crashes
        $s = isset($_POST['smtp']) ? explode(':', trim($_POST['smtp'])) : [];
        $proxyVal = isset($_POST['proxy']) ? trim($_POST['proxy']) : '';
        $p = !empty($proxyVal) ? explode(':', $proxyVal) : [];

        if (empty($s) || count($s) < 3) {
            throw new Exception("Invalid SMTP configuration format.");
        }

        // SMTP Settings
        $mail->isSMTP();
        $mail->Host        = $s[0];
        $mail->SMTPAuth    = true;
        $mail->Username    = $s[1];
        $mail->Password    = $s[2];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port        = 587;

        // SOCKS5 Proxy with Auth
        if (!empty($proxyVal) && count($p) >= 2) {
            $mail->SMTPOptions = array(
                'proxy' => array(
                    'host' => $p[0],
                    'port' => $p[1],
                    'type' => 'socks5',
                    'user' => $p[2] ?? '',
                    'pass' => $p[3] ?? ''
                )
            );
        }

        // Content & Obfuscation
        $subject = isset($_POST['subject']) ? processSpintax($_POST['subject']) : '';
        $mail->Subject = "=?UTF-8?B?" . base64_encode($subject) . "?=";
        $mail->setFrom($s[1], $_POST['sender_name'] ?? '');
        $mail->addAddress($_POST['target'] ?? '');
        $mail->isHTML(true);
        $mail->Body = isset($_POST['message']) ? processSpintax($_POST['message']) : '';

        // Custom Headers to bypass filters
        $mail->addCustomHeader('X-Mailer', 'Microsoft Outlook 16.0');
        $mail->addCustomHeader('Message-ID', '<' . bin2hex(random_bytes(10)) . '@' . $s[0] . '>');

        $mail->send();
        echo json_encode(["status" => "success", "message" => "Delivered to Inbox"]);

    } catch (Exception $e) {
        // Fallback to exception message if mailErrorInfo is empty
        $errorMsg = (!empty($mail->ErrorInfo)) ? $mail->ErrorInfo : $e->getMessage();
        echo json_encode(["status" => "error", "message" => $errorMsg]);
    }
}
?>